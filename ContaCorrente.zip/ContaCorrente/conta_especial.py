from conta_corrente import ContaCorrente

class ContaEspecial(ContaCorrente):
    def __init__(self, id, nome, saldo, limite):
        super().__init__(id, nome, saldo)
        self._limite = limite

    def Depositar(self, valor):
        super().Depositar(valor)
        return True
    
    def getLImite(self):
        return self._limite

    def setLImite(self,newlimite):
        self._limite = newlimite
    
    def Sacar(self,valor):

        if (super().getSaldo() > 0) and super().getSaldo() >= valor :
            total_saldo =  super().getSaldo() - valor
            super().setSaldo(total_saldo)

        elif (super().getSaldo() <= 0 and self._limite > 0 and self._limite <= valor):

            total_saldo =  super().getSaldo() - valor
            super().setSaldo(total_saldo)

            self._limite = self._limite - valor

        elif (super().getSaldo() + self._limite > 0 and super().getSaldo() + self._limite >= valor):

            #if (super().getSaldo() < 0):
            #total + limite
            saldo_total =  super().getSaldo() + self._limite 

            print("total disponivel",saldo_total)

            #total descontado
            saldo_final = saldo_total - valor
            print("saldo final ",saldo_final)

            sacado = valor
            print("sacado",sacado)
            #atualiza o limite
            sub = self._limite - valor  
            self._limite = sub
            #atualiza o saldo
           
            subsaldo = super().getSaldo() - valor 
            total = super().setSaldo(subsaldo)  
            print("saldo conta",subsaldo)
            
          
        else:
             print("\t Saldo Insuficiente !")
             return False

    

    def ToString(self):
         return f'Nome do Cliente :',super().getNome()
