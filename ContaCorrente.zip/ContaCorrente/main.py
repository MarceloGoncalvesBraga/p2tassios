
# from asyncio.windows_events import NULL
from cliente import Cliente
from conta_corrente import ContaCorrente
from conta_especial import ContaEspecial
from contasDao import Contas

# def main():


def Logo():
    print("\n\t-------------------------------------")
    print("\t           BANCO PRINCIPAL            ")
    print("\t-------------------------------------")

def Menu():
    print("\t     Escolha uma Opcao    ")

    print("\t 1 - Acessar Conta Corrente    ")
    print("\t 2 - Acessar Conta Especial    ")
    print("\t 3 - Criar Conta      ")
    print("\t 0 - Sair    ")


def MenuAbrirConta():
    print("\n\t-------------------------------------")
    print("\t           BANCO PRINCIPAL            ")
    print("\t-------------------------------------")
    print("\t 1 - Conta Corrente ")
    print("\t 2 - Conta Especial ")
    print("\t 0 - Sair ")
    print("\t-------------------------------------\n")

def MenuConta():
    print("\n\t-------------------------------------")
    print("\t           BANCO PRINCIPAL            ")
    print("\t-------------------------------------")
    print("\t 1 - Depositar ")
    print("\t 2 - Sacar ")
    print("\t 3 - Consultar Saldo")
    print("\t 4 - Tranferir ")
    print("\t 0 - Sair ")
    print("\t-------------------------------------\n")

def ConsultaContas(nome):
    contas = 0
    lista_clientes_contas = Contas.ClientesCC()
    lista_clientes_contas_especial = Contas.ClientesVip()
    while True:
        for user in lista_clientes_contas:
            if (user.getNome() == nome):
                contas = contas + 1
        for user in lista_clientes_contas_especial:
            if (user.getNome() == nome):
                contas = contas + 2
        return 
    # break

def ContaCC(lista_clientes_contas):

            nome_cliente = input("\n Nome de Cliente \n")
            for user in lista_clientes_contas:
             
              if(user.getNome() == nome_cliente):
               
                id_cliente = user.getId()
                cliente = user.getNome()
                print("\t Conta Encontrada: Olá ", cliente, " \t")
                ConsultaContas(cliente)
                while True:
                    MenuConta()
                    opcao = input("\t Digite a opção desejada: ")
                    if opcao == '1':

                        try:
                         valor = int(input("\t Digite o valor: "))
                         for user in lista_clientes_contas:
                            if(user.getNome() == cliente):
                             user.Depositar(valor)
                        except:
                            print('\t Valor invalido')
                    elif opcao == '2':

                        try:
                         valor = int(input("\tDigite o valor: "))
                         for user in lista_clientes_contas:
                            if(user.getNome() == cliente):
                             user.Sacar(valor)
                        except:
                            print('\tValor invalido')
                    elif opcao == '3':

                        Logo()
                        for user in lista_clientes_contas:
                            if(user.getNome() == cliente):
                             saldo = user.getSaldo()
                             print("\t SALDO DE R$: ", saldo)

                    elif opcao == '4':
                        conta = int(input("\tDigite a Conta-id: "))
                        valor = int(input("\tDigite o valor: "))
                        for user in lista_clientes_contas:
                            if(user.getNome() == cliente):
                                user.Sacar(valor)
                                for cc in lista_clientes_contas:
                                    if cc.getId() == conta:
                                        cc.Depositar(valor)
                                        print("\t Transferido para ",cc.getNome())
                                
                    elif opcao == '0':
                        return
                    
                    else:
                        print("\tOpcao Invalida")
def ContaES(lista_clientes_contas_especial):
            nome_cliente = input("\n Nome de Cliente \n")
            for user in lista_clientes_contas_especial:
                if(user.getNome() == nome_cliente):
                    id_cliente = user.getId()
                    cliente = user.getNome()
                    print("\t Conta Encontrada: Olá ", cliente, " \t")
                    ConsultaContas(cliente)
            if  cliente == 'x':
                    print("\t Cliente nao encontrado")
                    print("\t utilize a opcao 3 Criar Conta")
                    return Conta()
            while True:
                MenuConta()
                opcao = input("\t Digite a opção desejada: ")
                if opcao == '1': #---------------------------- Depositar
                    try:
                     valor = int(input("\t Digite o valor: "))
                     for user in lista_clientes_contas_especial:
                        if(user.getNome() == cliente):
                           user.Depositar(valor)
                    except:
                        print('\t Valor invalido')
                elif opcao == '2': #-------------------------- Sacar
                    try:
                     valor = int(input("\tDigite o valor: "))
                     for user in lista_clientes_contas_especial:
                        if(user.getNome() == cliente):
                           user.Sacar(valor)
                    except:
                        print('\tValor invalido')
                elif opcao == '3': #-------------------------- Saldo
                    Logo()
                    for user in lista_clientes_contas_especial:
                        if(user.getNome() == cliente):
                           saldo = user.getSaldo()
                           print("\t SALDO DE R$: ", saldo)
                           especial = user.getLImite()
                           print("\t Xeque Especial DE R$: ", especial)
                elif opcao == '4':#--------------------------- Transferir
                    conta = int(input("\tDigite a Conta-id: "))
                    valor = int(input("\tDigite o valor: "))
                    for user in lista_clientes_contas_especial:
                        if(user.getNome() == cliente):
                                user.Sacar(valor)
                                for ce in lista_clientes_contas_especial:
                                    if ce.getId() == conta:
                                        ce.Depositar(valor)
                                        print("\t*3 Tranferido para ",ce.getNome())
                            
                        
                elif opcao == '0':
                    return
                else:
                    print("\tOpcao Invalida")

def Conta():

    lista_clientes_contas = Contas.ClientesCC()
    lista_clientes_contas_especial = Contas.ClientesVip()
    cliente = 'x'
    id_cliente = 0    

    while True:
        Logo()
        Menu()
        opcao = input("\t Digite a opção desejada: \n")
        
        if opcao == '1':
            ContaCC(lista_clientes_contas)
        if opcao == '2':
            ContaES(lista_clientes_contas_especial)
        if(opcao == '3'):
          MenuAbrirConta()
          opcao = input("\t  Escolha uma opcao ")

          if opcao == '1':
            print("\t  Conta Corrente ")
            nome_cliente = input("\t Digite seu Nome: ")
            lista_clientes_contas.append((ContaCorrente(100, nome=nome_cliente, saldo=0)))

          elif opcao == '2':
            print("\t  Conta Especial ")
            nome_cliente = input("\t Digite seu Nome: ")
            lista_clientes_contas_especial.append((ContaEspecial(100, nome=nome_cliente, saldo=0, limite=500)))

          elif opcao == 0:
            exit()
          else:
            print("opca Invalida")


        elif opcao == '0':
          exit()


Conta()
#  for user in lista_clientes_contas_especial:
#                         if(user.getNome() == cliente):
#                             if (user.getSaldo() > 0 and user.getSaldo() <=valor):
#                                 total = user.getSaldo() - valor
#                                 #user.setSaldo(total)
#                                 user.Sacar(valor)
#                                 for ce in lista_clientes_contas_especial:
#                                     if ce.getId() == conta:
#                                         ce.Depositar(valor)
#                                         print("\t*1 Tranferido para ",ce.getNome())
#                             elif (user.getSaldo() <= 0 and user.getLImite() > 0 and user.getLImite() <= valor):
#                                 user.Sacar(valor)
#                                 #montante = user.getLImite() - valor
#                                 #user.setLImite(montante)
#                                 for ce in lista_clientes_contas_especial:
#                                     if ce.getId() == conta:
#                                         ce.Depositar(valor)
#                                         print("\t*2 Tranferido para ",ce.getNome())
#                             elif (user.getSaldo() + user.getLImite() > 0 and user.getSaldo() + user.getLImite() >= valor):
#                                 user.Sacar(valor)
#                                 for ce in lista_clientes_contas_especial:
#                                     if ce.getId() == conta:
#                                         ce.Depositar(valor)
#                                         print("\t*3 Tranferido para ",ce.getNome())
#                             else:
#                                 print("saldo Insuficiente")
                   