
class Cliente:
    def __init__(self, id, nome):
        self.__id = id
        self.nome = nome

    def getId(self):
        return self.__id
        
    def getNome(self):
        return self.nome

    #def setNome(self, nome):
    #   self.nome = nome
        
    def toString(self):
        return f'Nome do Cliente :',self.getNome()