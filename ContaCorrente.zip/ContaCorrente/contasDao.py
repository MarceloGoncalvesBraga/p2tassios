    
from conta_corrente import ContaCorrente
from conta_especial import ContaEspecial

class Contas:

    def ClientesCC():

        lista_clientes_contas = [
            ContaCorrente(1,"marcelo",0),
            ContaCorrente(2,"erika",0),
            ContaCorrente(3,"amanda",0),
            ContaCorrente(4,"vania",0),
        ]
        return lista_clientes_contas

    def ClientesVip():

        lista_clientes_contas_especial = [
            ContaEspecial(1,"marcelo",0,500),
            ContaEspecial(2,"erika",0,1000),
            ContaEspecial(3,"brasil",0,700),
            ContaEspecial(4,"vania",0,1500),
        ]
        return lista_clientes_contas_especial